/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio34;

/**
 *
 * @author diego
 */
public class Main {
    public static void main (String args[]) {
        Pessoa pessoas [] = new Pessoa [10];
        for (int i = 0; i < pessoas.length; i ++) {
            pessoas[i] = new Pessoa("Pessoa " + (i + 1), (double) i/10 + 0.5, 30 + i);
        }
        for (int i = 0; i < pessoas.length; i ++) {
            System.out.printf("Nome: %s, Altura: %.2f, Peso: %.2f\n",
                    pessoas[i].getNome(),
                    pessoas[i].getAltura(),
                    pessoas[i].getPeso());
        }
    }
}