
package exercicio42;

public class Funcionario {
    String nome;
    String departamento;
    double salario;
    String RG;
    boolean empregado;

    public Funcionario(String nome, String departamento, double salario, String RG) {
        this.nome = nome;
        this.departamento = departamento;
        this.salario = salario;
        this.RG = RG;
        this.empregado = true;
    }

    public Funcionario(String nome, String RG) {
        this.nome = nome;
        this.RG = RG;
        this.empregado = true;
    }

    public Funcionario() {
        this.empregado = true;
    }
    
}
