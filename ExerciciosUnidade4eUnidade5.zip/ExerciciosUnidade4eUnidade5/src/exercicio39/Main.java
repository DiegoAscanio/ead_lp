/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio39;

/**
 *
 * @author diego
 */
public class Main {
    public static void main (String args[]) {
        Pessoa p = new Pessoa();
        p.setNome("Diego");
        p.setIdade(25);
        p.setAltura(1.84);
        p.setPeso(103);
        System.out.println(p);
        System.out.println("---------- Depois que Fizer Aniversário ----------");
        p.aniversario();
        System.out.println(p);
    }
}