/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio39;

import exercicio34.*;

/**
 *
 * @author diego
 */
public class Pessoa {
    private String nome;
    private double altura;
    private double peso;
    private int idade;

    public Pessoa() {
    }

    public Pessoa(String nome, double altura, double peso, int idade) {
        this.nome = nome;
        this.altura = altura;
        this.peso = peso;
        this.idade = idade;
    }
    
    public void aniversario() {
        this.idade += 1;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public int getIdade() {
        return idade;
    }
    
    public String getNome() {
        return nome;
    }

    public double getAltura() {
        return altura;
    }

    public double getPeso() {
        return peso;
    }
    
    public String toString() {
        return "Pessoa: " + this.nome + ", Altura: " + this.altura + ", Peso: " + this.peso + ", Idade: " + this.idade;
    }
}
