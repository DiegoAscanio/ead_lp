
package exercicio41;

public class Empresa {
    String nome;
    String cnpj;
    int quantidadeFuncionarios;
    Funcionario funcionarios[];

    public Empresa(String nome, String cnpj, int tamanhoArrayFuncionarios) {
        this.nome = nome;
        this.cnpj = cnpj;
        this.funcionarios = new Funcionario[tamanhoArrayFuncionarios];
        this.quantidadeFuncionarios = 0;
    }

    public Empresa(String nome, String cnpj) {
        this.nome = nome;
        this.cnpj = cnpj;
        this.quantidadeFuncionarios = 0;
        this.funcionarios = new Funcionario[100];
    }
    
}
