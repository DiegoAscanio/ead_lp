
package exercicio43;

public class Empresa {
    String nome;
    String cnpj;
    int quantidadeFuncionarios;
    Funcionario funcionarios[];
    private int cursorInsercaoFuncionario;
    private int quantidadeHistoricaFuncionarios;

    public Empresa(String nome, String cnpj, int tamanhoArrayFuncionarios) {
        this.nome = nome;
        this.cnpj = cnpj;
        this.cursorInsercaoFuncionario = 0;
        this.quantidadeFuncionarios = 0;
        this.quantidadeHistoricaFuncionarios = 0;
        this.funcionarios = new Funcionario[tamanhoArrayFuncionarios];
    }

    public Empresa(String nome, String cnpj) {
        this.nome = nome;
        this.cnpj = cnpj;
        this.cursorInsercaoFuncionario = 0;
        this.quantidadeFuncionarios = 0;
        this.quantidadeHistoricaFuncionarios = 0;
        this.funcionarios = new Funcionario[100];
    }
    
    public int numeroFuncionarios() {
        return this.quantidadeFuncionarios;
    }
    
    public void admitirFuncionario(Funcionario funcionario) {
        funcionarios[this.cursorInsercaoFuncionario] = funcionario;
        this.quantidadeFuncionarios += 1;
        this.quantidadeHistoricaFuncionarios += 1;
        
        // reposiciona cursor de insercao de funcionarios para proxima posicao
        // nula do vetor, pois, podem haver vazios entre funcionarios do vetor
        int i;
        for (i = 0; i < this.quantidadeHistoricaFuncionarios; i ++) {
            if (funcionarios[i] == null) {
                break;
            }
        }
        this.cursorInsercaoFuncionario = i;
    }
    
    public void demitirFuncionario(Funcionario funcionario) {
        for (int i = 0; i < funcionarios.length; i ++) {
            if (funcionarios[i] == funcionario && funcionarios[i] != null) {
                funcionarios[i] = null;
                this.quantidadeFuncionarios -= 1;
                // reposiciona cursor de funcionario
                this.cursorInsercaoFuncionario = i;
            }
        }
    }

    public int getCursorInsercaoFuncionario() {
        return cursorInsercaoFuncionario;
    }
    
}
