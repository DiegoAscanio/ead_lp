/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio43;

/**
 *
 * @author diego
 */
public class Main {
    public static void main (String args[]) {
        Empresa e = new Empresa("CEFET-MG", "17.220.203/0001-96");
        Funcionario f1 = new Funcionario("Diego", "121314");
        e.admitirFuncionario(f1);
        Funcionario f2 = new Funcionario("Jose", "131412");
        e.admitirFuncionario(f2);
        Funcionario f3 = new Funcionario("Sergio", "111412");
        e.admitirFuncionario(f3);
        Funcionario f4 = new Funcionario("Maria", "131212");
        e.admitirFuncionario(f4);
        e.demitirFuncionario(f3);
        e.demitirFuncionario(f2);
        System.out.println("Quantidade funcionarios: " + e.numeroFuncionarios());
        // chamada destrutor
        e.demitirFuncionario(f4);
        f4 = null;
        System.gc();
    }
}
