/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio33;

/**
 *
 * @author diego
 */
public class Main {
    public static void main (String args[]) {
        Pessoa p1 = new Pessoa("Diego", 1.84, 103);
        Pessoa p2 = new Pessoa("Jose", 1.8, 100);
    }
}
